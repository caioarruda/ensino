SELECT 
contribuinte_id 
FROM public.cmt_imovel
where id = 3685