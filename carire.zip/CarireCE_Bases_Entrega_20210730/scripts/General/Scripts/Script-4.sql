select * 
from eventosnegocios e 
where extra_data like '%0001%'