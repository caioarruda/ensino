



select * from divida_ativa_dam dad where id in (
	select * from divida_ativa_historico_negociacao dahn where lancamentodiat_id = 2601
)

select * from lanc_diat ld where id = 2623

from lanc_dam ld where lancamentodiat_id is not null


select * from zzdebitosimobiliarios z where sequencial = '10000224'

select * from zzdebitosimobiliariosparcelados z where parcelamento = '100058191'