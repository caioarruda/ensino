drop table zzexercicios;

select
distinct
concat(ci.im,' - ',di.exerccio) as chave,
ci.im as imovel_id,
di.exerccio as exercicio,
case when di.inscrio_dvida_ativa <> '' then 'INSCRITO' else null end as INSCRITO,
ci.doc
into zzexercicios
FROM public.zzdebitosimobiliarios di
join zzcadastroimobiliario ci on ci.sequencial = di.sequencial ;

drop table zzimoveis_exercicios_a_inserir;

select 
*
into zzimoves_exercicios_a_inserir
from zzexercicios z 
where z.chave not in (
	select concat(ld.imovel_id,' - ',ld.exercicio) 
	from lanc_dam ld
)
order by imovel_id;

select * from zzimoves_exercicios_a_inserir ;

