--select * from CDT_T_PESSOAFISICA ctp where DS_NOME like '%Alzirene%sousa%' 543793
--select * from CDT_T_CONTA ctc where ID_PESSOAFISICA = 543793 -- 276116, 1356464, 1866112
--select * from CDT_T_FATURA ctf where ID_CONTA in (276116, 1356464, 1866112)
--select * from CDT_T_TRANSACAOFATURA ctt where ID_FATURA = 178284079
select * from FBR_API_T_EVENTOSNEGOCIOS fate
where 
resource LIKE '%accountid%'
and created_at > '2021-12-01'