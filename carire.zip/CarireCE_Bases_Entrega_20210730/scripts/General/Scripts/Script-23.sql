SELECT sequencial, exerccio, parcela, vencimento, valor_original_do_iptu, valor_original_da_tlp, valor_original_da_tip, situao, dt_pagamento, valor_pago, valor_atual_em_aberto_sem_acrscimos, inscrio_dvida_ativa, data_certido, processo_judicial, parcelamento, qtd_parcelas, vencimento_1, valor_total_original, parcelas_pagas, parcelas_desativadas, "_col8081"
FROM public.zzdebitosimobiliarios;
