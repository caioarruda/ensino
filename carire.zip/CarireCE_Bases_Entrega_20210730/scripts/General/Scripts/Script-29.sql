select 
id, damorigem_id 
into zzdams_a_cancelar
from divida_ativa_dam dad 
where tipodam = 0 and id not in (select id from zzdividas_manter)


update divida_ativa_dam set datacancelamento = now(),
observacaocancelamento = 'CONCILIA��O: Remo��o de dados duplicados ou sem refer�ncia de imovel',
numeroprocessocancelamento = now(),
tipocancelamentodivida = 0
where tipodam = 0 and id not in (select id from zzdividas_manter)


update lanc_dam ld 
set 
observacao = 'CONCILIA��O: Remo��o de dados duplicados ou sem refer�ncia de imovel',
dataexpurgo = now()
where id in (select damorigem_id from zzdams_a_cancelar zac)

delete from divida_ativa_historico_negociacao where lancamentodiat_id >= 2623 and lancamentodiat_id < 24000;

select *  from lanc_diat ld order by id desc

delete  from divida_ativa_dam dad where id >= 78961;

delete from lanc_dam ld where id >= 94173;

select * from zzdebitosimobiliarios z 



select * from lanc_dam where lancamentodiat_id > 2630