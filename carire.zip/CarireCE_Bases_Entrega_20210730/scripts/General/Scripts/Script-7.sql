select CONCAT('resource like ','''','%/',ID_CARTAO,'/%','''',' or ')  ,*
from CDT_T_CARTAO ctc 
where  ID_PESSOAFISICA = 2969858  


--select * from CDT_T_CARTAO ctc where ID_CARTAO = 5523345