select * from CDT_T_PESSOAFISICA ctp 
where NU_CPF = '02417801019'