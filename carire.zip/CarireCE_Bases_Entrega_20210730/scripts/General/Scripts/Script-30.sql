

select distinct situao  
from zzdebitosimobiliarios z;

select * from zzdebitosimobiliariosparcelados z;

select * from zzdams where identificador = '10000801';

select * from zzdividas z where sequencial = '10000801';

select * from zzcadastroimobiliario z ;

select contribuinte_id from cmt_imovel ci where concat(id,'') = (select p1 from zzcadastroimobiliario where sequencial = '10000801')

select * from lanc_dam ld where datatransferencia > '2021-07-30' or datapagamento >= '2021-07-30' and tipodam = 0

select * from lanc_dam where LOWER(observacao) like '%migr%'

select 
id 
into zzdividas_manter
from divida_ativa_dam dad where datanegociacao < '2021-12-30' and datanegociacao > '2020-01-01' and tipodam = 0

select count(*) from divida_ativa_dam dad


select * from divida_ativa_historico_negociacao dahn order by id 


select *  from lanc_diat ld where id not in (select lancamentodiat_id from divida_ativa_historico_negociacao )

select * from divida_ativa_dam dad where imovel_id = 228 and anolivro = 2019

select * from lanc_dam where observacao like '%INSERT%'  order by observacao asc


select * from zzdividas z 

select * from zzdebitosimobiliariosparcelados z where parcelamento = '100058191'
