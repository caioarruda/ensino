SELECT id, userName, accountId, active, typeFinancialService, nameFinancialService, success, recurrentDebitId, createdAt
FROM db_servicos.log_servico_financeiro;
