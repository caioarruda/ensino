select id, anolivro, exercicio, exercicio_base, datainscricao, datanegociacao , valor, damorigem_id, origemextradam, lancamentodiat_id 
from divida_ativa_dam 
where imovel_id = 1826
order by exercicio_base, datainscricao desc


select contribuinte_id, imovel_id, sequencial, valor from lanc_dam ld where sequencial = 70
order by datavencimento, sequencial 

select * from divida_ativa_dam dad where valor = 171.16

select * from lanc_iptu li where li.imovel_id = 684

select * from lanc_dam ld where lancamentodiat_id = 24211

select * from lanc_dam ld where contribuinte_id = 601

select * from cmt_contribuinte cc where id = 601

select 
z.sequencial, 
z.valor_original_do_iptu, 
z2.im, 
z.data_certido,
z.vencimento,
z.parcela,
z.exerccio 
from zzdebitosimobiliarios z 
join zzcadastroimobiliario z2 on z2.sequencial = z.sequencial 
join cmt_contribuinte cc on cc.documento = replace(replace(z2.doc,'.',''),'-','') and z2.doc is not null
where 
cc.id = 601

