update zzcadastroimobiliario 
set im = case when p1 is null or char_length(p1) >= 6 then null else p1::integer  end