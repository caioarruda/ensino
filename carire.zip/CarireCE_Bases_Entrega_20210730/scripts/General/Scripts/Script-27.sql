SELECT  
*
FROM  zzdebitosimobiliariosparcelados 
where 
parcelamento = '100024211';

select * from zzdebitosimobiliarios z 
where sequencial = '10018263';
