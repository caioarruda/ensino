SELECT id, userName, accountId, active, typeFinancialService, nameFinancialService, success, recurrentDebitId, createdAt
FROM dbservicosfinanceiros.dbo.t_log_servico_financeiro;
