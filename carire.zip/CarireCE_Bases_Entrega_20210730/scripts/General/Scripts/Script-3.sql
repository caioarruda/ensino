select * from logapppurchases l 
where 
l.hora_compra > '20211103' and
resposta_status = 200
order by numero_aparelho, id_usuario, l.hora_compra desc 