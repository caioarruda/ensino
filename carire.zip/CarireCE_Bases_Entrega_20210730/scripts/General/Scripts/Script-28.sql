select 
ld.id,
ld.sequencial,
ld.numeroparcela,
ld.imovel_id,
ld.observacao, 
ld.exercicio,
ld.datavencimento,
ld.dataemissao,
ld.valor,
z3.parcela as "parcela_mig",
z3.exerccio as "exercicio_mig",
z3.vencimento as "vencimento_mig",
z3.data_certido as "emissao_mig", 
z3.valor_original_do_iptu  as "valor_mig"
from 
lanc_dam ld 
join zzcadastroimobiliario z2 on z2.im = ld.imovel_id 
join zzdebitosimobiliarios z3 on z3.sequencial = z2.sequencial  and z3.exerccio = concat(ld.exercicio,'') and z3.parcela = concat(ld.numeroparcela,'')

