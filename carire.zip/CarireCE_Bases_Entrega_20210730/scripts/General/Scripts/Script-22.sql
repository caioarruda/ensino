select 
ci.inscricaomunicipal,
cl.nomeoficial as rua,
ci.numero,
ci.lote,
ci.complemento,
ci.quadra,
cb.nome as bairro
from cmt_imovel ci 
join cmt_logradouro cl on cl.id = ci.logradouro_id 
join cmt_bairro cb  on cb.id = ci.bairro_id 
where inscricaomunicipal = 3262