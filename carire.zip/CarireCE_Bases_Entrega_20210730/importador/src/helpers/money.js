function toUS(valor) {
    return valor.toString().replace('.', '').replace(',', '.');
}

module.exports = { toUS };