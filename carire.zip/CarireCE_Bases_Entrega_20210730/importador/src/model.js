const { convertDate } = require("./helpers/date");
const { toUS } = require("./helpers/money");

let db;

function init(database) {
    db = database;
}

async function getImoveis() {
    const imoveis = await db.getCadastroImobiliario();
    return imoveis?.rows
}

async function getDebitos(imovel) {
    const debitos = await db.getDebitos(imovel.sequencial);
    return debitos?.rows
}

async function getParcelas(parcelamento) {
    const parcelas = await db.getDebitosParcelados(parcelamento);
    return parcelas?.rows
}
async function getParcelamentos() {
    const parcelas = await db.getParcelamentos();
    return parcelas?.rows
}
async function getDams(exercicio, parcela, imovel) {
    const dams = await db.getDams(exercicio, parcela, imovel);
    return dams?.rows
}

async function getNextSequencial(contribuinte) {
    const sequencial = await db.getMaxSequencial(contribuinte);
    return Number(sequencial?.rows[0].sequencial) + 1
}
async function getNextSequencialDivida(contribuinte) {
    const sequencial = await db.getMaxSequencialDivida(contribuinte);
    return Number(sequencial?.rows[0].sequencial) + 1
}
async function insertDam(dam, tipodam) {
    if (dam.exerccio == '2021') {
        const dams = await db.ifExistsDam(convertDate(dam.vencimento), toUS(dam.valor), dam.imovel_id, dam.contribuinte_id);
        if (dams?.rows.length > 0) {
            return false;
        }
    }
    const sequencial = await getNextSequencial(dam.contribuinte_id);
    const damm = await db.insertDam(dam, sequencial, tipodam);
    return damm.rows[0].id
}
async function insertDivida(divida, tipodam, damorigem) {
    const sequencial = await getNextSequencialDivida(divida.contribuinte_id);
    divida.lancamentodiat_id = null;
    divida.ultimovencimento = divida.vencimento;
    divida.damorigem_id = damorigem;
    const dividaa = await db.insertDivida(divida, sequencial, tipodam);
    return dividaa.rows[0].id
}

async function updateDam(dam, id) {
    const damm = await db.updateDam(dam, id);
    return damm;
}

async function updateObsDam(observacao, id, dam) {
    const damm = await db.updateObsDam(observacao, id, dam);
    return damm;
}


async function getDividas(exercicio, contribuinte, imovel) {
    const dividas = await db.getDividas(exercicio, contribuinte, imovel);
    return dividas?.rows
}

async function insertDiat(diat) {
    const id = await db.insertDiat(diat);
    return id.rows[0].id
}

async function insertDiatDam(diat) {
    const id = await db.insertDiatDam(diat);
    return id.rows[0].id
}

async function insertHistoricoDiat(dividaid, diatid) {
    const id = await db.insertHistoricoDiat(dividaid, diatid);
    return id.rows[0].id
}

module.exports = {
    init,
    getParcelas,
    getDebitos,
    getImoveis,
    getDams,
    insertDam,
    updateDam,
    updateObsDam,
    getDividas,
    insertDivida,
    insertDiat,
    insertDiatDam,
    insertHistoricoDiat,
    getParcelamentos
};