const { Pool, Client } = require("pg");
const db = require("./db");
const { convertDate, getYear } = require("./helpers/date");
const { toUS } = require("./helpers/money");
const model = require("./model");
const credentials = {
    user: "postgres",
    host: "teste.siamnet.com.br",
    database: "siam",
    password: "SIAMNET@1677#",
    port: 5432,
};

async function inserirDam(dam) {
    const id = await model.insertDam(dam, dam.tipodam ? dam.tipodam : 0);
    return id;
}
async function inserirDiatDam(dam) {
    const id = await model.insertDiatDam(dam);
    return id;
}
async function inserirDivida(divida, damorigem) {
    const id = model.insertDivida(divida, 0, damorigem);

    return id;
}

async function inserirDebitoSemParcelamento(debito) {
    if (!debito) return false;
    if ((
        debito?.inscrio_dvida_ativa != null
        && debito?.inscrio_dvida_ativa != ''
        && debito.situao != "COM PAGAM/DESAT"
    ) || (
            debito.parcelamento != null
            && debito.parcelamento != ''
        )) {
        //conciliarDivida(debito);
        const id = await inserirDam(debito);
        const iddivida = await inserirDivida(debito, id);

        console.log("inserindo Divida ===>", iddivida)
        return { id: iddivida, divida: true };
    } else {
        const id = await inserirDam(debito);
        console.log("inserindo DAM ===>", id)
        return { id: id, divida: false };
    }
}

async function criarDiat(parcelamento, parcelas) {
    const diat = {};
    const parcela = parcelas[0];
    const ultimaParcela = parcelas[parcelas.length - 1];
    diat.dataemissao = parcela.dataparcelamento ? convertDate(parcela.dataparcelamento) : null;
    diat.exercicio = convertDate(parcela.vencimento).getFullYear();
    diat.numeroparcelas = parcelas.length;
    diat.primeirovencimento = parcela.vencimento ? convertDate(parcela.vencimento) : null;
    diat.ultimovencimento = ultimaParcela.vencimento ? convertDate(ultimaParcela.vencimento) : null;
    diat.valorpago = toUS(parcela.valorpago ? parcela.valorpago : 0);
    diat.valortotal = toUS(parcelamento.debito.valor_total_original ? parcelamento.debito.valor_total_original : 0);
    diat.contribuinte_id = parcelamento.debito.contribuinte_id;
    diat.statusnegociacao = 0;
    diat.dataatualizacao = diat.dataemissao;
    diat.obs = "CONCILIACAO INSERT: im_id: " + parcelamento.debito.imovel_id + " - " + new Date().toLocaleDateString() + " - c_id: " + parcelamento.debito.contribuinte_id;
    const diatId = await model.insertDiat(diat);
    diat.id = diatId;
    return diat;
}

async function criarDiatDams(parcelamento, parcelas, diat) {
    const ids = [];
    for (const parcela of parcelas) {
        const damDiat = {};
        damDiat.aliquota = 0;
        damDiat.codigobarras = "";
        damDiat.codigobarrascomespacos = "";
        damDiat.codigobarrassemdv = "";
        damDiat.correcao = 0;
        damDiat.datacredito = null;
        damDiat.dataexpurgo = null;
        damDiat.datapagamento = parcela.datapagamento ? convertDate(parcela.datapagamento) : null;
        damDiat.datatransferencia = null;
        damDiat.datavencimento = parcela.vencimento ? convertDate(parcela.vencimento) : null;
        damDiat.exercicio = getYear(convertDate(parcela.vencimento));
        damDiat.juros = 0;
        damDiat.multa = 0;
        damDiat.numeroparcela = parcela.parcela;
        damDiat.observacao = "CONCILIACAO INSERT: im_id: " + parcelamento.debito.imovel_id + " - " + new Date().toLocaleDateString() + " - c_id: " + parcelamento.debito.contribuinte_id;
        damDiat.percentualdesconto = 0;
        damDiat.sequencial = parcela.sequencial;
        damDiat.statusdam = parcela.valorpago ? 1 : 0;
        damDiat.taxaexpediente = 0;
        damDiat.tipodam = 12;
        damDiat.totalparcelas = parcelas.length;
        damDiat.valor = parcela.valor ? toUS(parcela.valor) : 0;
        damDiat.valordesconto = 0;
        damDiat.valorpagamento = parcela.valorpago ? toUS(parcela.valorpago) : 0;
        damDiat.valorpago = parcela.valorpago ? toUS(parcela.valorpago) : 0;
        damDiat.valortotal = parcela.valor ? toUS(parcela.valor) : 0;
        damDiat.valortotalbase = parcela.valor ? toUS(parcela.valor) : 0;
        damDiat.contribuinte_id = parcelamento.debito.contribuinte_id;
        damDiat.imovel_id = parcelamento.debito.imovel_id;
        damDiat.lancamentodiat_id = diat.id;
        const id = await inserirDiatDam(damDiat);
        console.log("inserindo DAM de Diat ===>", id, ' - ', damDiat.datavencimento, " - ", parcela.parcela, " - R$ ", parcela.valorpago, " - R$ ", parcelamento.debito.valor_total_original)
        ids.push(id);
    }
    return ids;
}

async function criarHistorico(dividaId, diat) {
    const id = model.insertHistoricoDiat(dividaId, diat.id);
    return id;
}

(async () => {
    const client = new Client(credentials);
    let countDiatDam = 0;
    await db.init(client);
    model.init(db);
    const inseridos = [];
    // const parcs = await model.getParcelamentos();
    // const aInserir = parcs.filter(p => inseridos.indexOf(p.parcelamento) == -1);
    // for (const index in parcs) {
    //     if (inseridos.indexOf(index) > -1) {
    //         console.log("parcelamento ja inserido", index);
    //         continue;
    //     }
    //     const parcelamento = parcs[index];
    //     const parcelas = await model.getParcelas(index);
    //     const diat = await criarDiat(parcelamento, parcelas);
    //     const ids = await criarDiatDams(parcelamento, parcelas, diat);
    //     const idHistorico = await criarHistorico(parcelamento.divida_id, diat);
    //     inseridos.push(parcelamento.parcelamento);
    //     countDiatDam += ids.length;
    // }
    const imoveis = await model.getImoveis();
    for (const imovel of imoveis) {
        const debitos = await model.getDebitos(imovel);
        const parcelamentos = {}
        for (const debito of debitos) {
            const dadosDebito = await inserirDebitoSemParcelamento(debito);
            if (debito.parcelamento != null && debito.parcelamento != '') {
                if (!parcelamentos[debito.parcelamento]) {
                    parcelamentos[debito.parcelamento] = [];
                }
                parcelamentos[debito.parcelamento].push({ debito, dadosDebito });
            }
        }
        for (const index in parcelamentos) {
            if (inseridos.indexOf(index) > -1) {
                console.log("parcelamento ja inserido", index);
                continue;
            }
            inseridos.push(index);
            const parcelamento = parcelamentos[index];
            const parcelas = await model.getParcelas(index);
            const diat = await criarDiat(parcelamento[0], parcelas);
            console.log("Inserindo diat ===> " + diat.id);
            const ids = await criarDiatDams(parcelamento[0], parcelas, diat);
            countDiatDam += ids.length;
            console.log("Dams Diat ===> " + ids.length);
            for (const p of parcelamento) {
                const id = await criarHistorico(p.dadosDebito.id, diat);
                console.log("Historico ===> " + id, p.dadosDebito.id, diat.id);
            }
        }
        console.log("Imovel ===> " + imovel.p1 + " - Qtd Diat atual: " + countDiatDam);
    }

    console.log("FIM ====> Qtd Diat atual: " + countDiatDam);
})();

