function convertDate(dt) {
    return new Date(dt.split("/").reverse().join("-") + " 10:00:00");
}

function getYear(dt) {
    return dt.getFullYear();
}

module.exports = { convertDate, getYear }