const { convertDate } = require("./helpers/date");
const { toUS } = require("./helpers/money");


let pool;

async function init(client) {
    pool = client;
    return client.connect();
}

async function getContribuintes() {
    const text = `SELECT id, documento FROM cmt_contribuinte`;
    return pool.query(text);
}

async function getCadastroImobiliario() {
    const text = `SELECT distinct zci.*, zdi.sequencial FROM zzcadastroimobiliario zci
    join zzdebitosimobiliarios zdi on zdi.sequencial = zci.sequencial
    where p1 is not null 
    and p1 <> '-' 
    and p1 <> '' 
    and char_length(p1) < 6`;
    return pool.query(text);
}

async function ifExistDam(vencimento, valor, imovel_id, contribuinte_id) {
    const text = `
        select * from lanc_dam where vencimento = $1 and valor = $2 and imovel_id = $3 and contribuinte_id = $4 and tipodam = 0
    `;
    return pool.query(text, [vencimento, valor, imovel_id, contribuinte_id]);
}

async function getDebitos(sequencial) {
    const text = `
        SELECT distinct zdi.*, zci.p1 as imovel_id, i.contribuinte_id
        FROM zzdebitosimobiliarios zdi
        JOIN zzcadastroimobiliario zci on zci.sequencial = zdi.sequencial
        LEFT JOIN cmt_imovel i on concat(i.id,'') = zci.p1
        WHERE zdi.sequencial = $1
    `;
    return pool.query(text, [sequencial]);
}


async function getDebitosParcelados(parcelamento) {
    const text = `
        SELECT *
        FROM zzdebitosimobiliariosparcelados zdip
        WHERE parcelamento = $1
    `;
    return pool.query(text, [parcelamento]);
}

async function getParcelamentos() {
    const text = `
        SELECT *
        FROM zzdebitosimobiliariosparcelados zdip
    `;
    return pool.query(text, []);
}

async function getMaxSequencial(contribuinte_id) {
    const text = `
        select max(sequencial) as sequencial from lanc_dam where contribuinte_id = $1
    `;
    return pool.query(text, [contribuinte_id]);
}
async function getMaxSequencialDivida(contribuinte_id) {
    const text = `
        select max(sequencial) as sequencial from divida_ativa_dam where contribuinte_id = $1
    `;
    return pool.query(text, [contribuinte_id]);
}
async function getDams(exercicio, parcela, imovel) {
    const text = `
        SELECT *
        FROM lanc_dam ld
        WHERE
        tipodam = 0 
        and exercicio = $1 
        and numeroparcela = $2
        and imovel_id = $3 
    `;
    return pool.query(text, [exercicio, parcela, imovel]);
}



async function insertDam(dam, sequencial, tipodam) {
    const datapagamento = dam.dt_pagamento ? convertDate(dam.dt_pagamento) : null;
    const transferido = dam?.inscrio_dvida_ativa != null && dam?.inscrio_dvida_ativa != '' && dam.situao != "COM PAGAM/DESAT"
    const datatransferencia = transferido ? new Date((Number(dam.exerccio) + 1).toString() + "/01/03") : null;
    const datavencimento = dam.vencimento ? convertDate(dam.vencimento) : null;
    const exercicio = dam.exerccio;
    const sequenciall = sequencial;
    const numeroparcela = dam.parcela;
    const statusdam = datapagamento ? 1 : (datatransferencia ? 3 : 2);
    const totalparcelas = dam.qtd_parcelas ? dam.qtd_parcelas : 0;
    const valor = dam.valor_original_do_iptu ? toUS(dam.valor_original_do_iptu) : 0;
    const valorpago = dam.valor_pago ? toUS(dam.valor_pago) : 0;
    const contribuinte_id = dam.contribuinte_id;
    const imovel_id = dam.imovel_id;
    const dataemissao = datapagamento ? datapagamento : datavencimento;
    const observacao = "CONCILIACAO INSERT: " + dam.situao + " - " + new Date().toLocaleDateString() + " - " + dam.sequencial;
    const text = `
    INSERT INTO lanc_dam (
        datapagamento, datatransferencia, datavencimento, exercicio, sequencial,
        numeroparcela, statusdam, totalparcelas, valor, valorpagamento, 
        valorpago, valortotal, contribuinte_id, imovel_id, dataemissao, 
        observacao, tipodam, aliquota, correcao, juros, multa, taxaexpediente, valordesconto, valortotalbase, percentualdesconto )
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, 0, 0, 0, 0, 0, 0, 0, 0)
    RETURNING id
  `;
    return pool.query(text, [
        datapagamento, datatransferencia, datavencimento, exercicio, sequenciall,
        numeroparcela, statusdam, totalparcelas, valor, valorpago, valorpago, valor, contribuinte_id, imovel_id, dataemissao,
        observacao, tipodam
    ])
}

async function insertDiatDam(dam) {
    const {
        aliquota,
        codigobarras,
        codigobarrascomespacos,
        codigobarrassemdv,
        correcao,
        datacredito,
        dataexpurgo,
        datapagamento,
        datatransferencia,
        datavencimento,
        exercicio,
        juros,
        multa,
        numeroparcela,
        observacao,
        percentualdesconto,
        sequencial,
        statusdam,
        taxaexpediente,
        tipodam,
        totalparcelas,
        valor,
        valordesconto,
        valorpagamento,
        valorpago,
        valortotal,
        valortotalbase,
        contribuinte_id,
        imovel_id,
        lancamentodiat_id
    } = dam;
    let args = '';
    for (let i = 1; i <= Object.keys(dam).length; i++) {
        args += ` $` + i;
        if (i < Object.keys(dam).length) {
            args += `, `;
        }
    }

    const text = `
    INSERT INTO lanc_dam (
        aliquota,
        codigobarras,
        codigobarrascomespacos,
        codigobarrassemdv,
        correcao,
        datacredito,
        dataexpurgo,
        datapagamento,
        datatransferencia,
        datavencimento,
        exercicio,
        juros,
        multa,
        numeroparcela,
        observacao,
        percentualdesconto,
        sequencial,
        statusdam,
        taxaexpediente,
        tipodam,
        totalparcelas,
        valor,
        valordesconto,
        valorpagamento,
        valorpago,
        valortotal,
        valortotalbase,
        contribuinte_id,
        imovel_id,
        lancamentodiat_id )

        VALUES (
            ${args}
        )
        
        RETURNING id

        `
    return pool.query(text, [
        aliquota,
        codigobarras,
        codigobarrascomespacos,
        codigobarrassemdv,
        correcao,
        datacredito,
        dataexpurgo,
        datapagamento,
        datatransferencia,
        datavencimento,
        exercicio,
        juros,
        multa,
        numeroparcela,
        observacao,
        percentualdesconto,
        sequencial,
        statusdam,
        taxaexpediente,
        tipodam,
        totalparcelas,
        valor,
        valordesconto,
        valorpagamento,
        valorpago,
        valortotal,
        valortotalbase,
        contribuinte_id,
        imovel_id,
        lancamentodiat_id
    ])
}

async function insertDivida(divida, sequencial, tipodam) {
    const datapagamento = divida.dt_pagamento ? convertDate(divida.dt_pagamento) : null;
    const datainscricao = new Date((Number(divida.exerccio) + 1).toString() + "/01/03");
    const datavencimento = divida.vencimento ? convertDate(divida.vencimento) : null;
    const exercicio = divida.exerccio;
    const sequenciall = sequencial;
    const numeroparcela = divida.parcela;
    const statusdam = datapagamento ? 1 : (datainscricao ? 3 : 2);
    const totalparcelas = divida.qtd_parcelas ? divida.qtd_parcelas : 0;
    const valor = divida.valor_original_do_iptu ? toUS(divida.valor_original_do_iptu) : 0;
    const valorpago = divida.valor_pago ? toUS(divida.valor_pago) : 0;
    const contribuinte_id = divida.contribuinte_id;
    const imovel_id = divida.imovel_id;
    const dataemissao = datapagamento ? datapagamento : datavencimento;
    const observacao = "CONCILIACAO INSERT: " + divida.situao + " - " + new Date().toLocaleDateString() + " - " + divida.sequencial;
    const lancamentodiat_id = divida.lancamentodiat_id;
    const damorigem_id = divida.damorigem_id;
    const ultimovencimento = divida.ultimovencimento ? convertDate(divida.ultimovencimento) : null;;
    const text = `
    INSERT INTO public.divida_ativa_dam
    (
        anolivro, correcao, correcaotransferida, dataatualizacaovalores, datacancelamento, 
        datainscricao, datanegociacao, exercicio, exercicio_base, fundamentolei, 
        juros, jurostransferido, multa, multatransferida, numeroacordao, 
        numeroprocesso, numeroprocessocancelamento, observacao, observacaocancelamento, origemextradam, 
        primeirovencimento, sequencial, tipocancelamentodivida, tipodam, tipodivida, 
        totalparcelas, ultimovencimento, valor, contribuinte_id, imovel_id, 
        lancamentodiat_id, damorigem_id, termoinscricao_id, executadajudicialmente, dataexecucaojudicial, 
        lancamentodividaanterior)
     VALUES(
        $1, 0, 0, now(), null, 
        $13, null, $1, $1, '', 
        0, 0, 0, 0, null, 
        null, null, $2, '', null, 
        $3, $4, null, $5, 0, 
        $6, $7, $8, $9, $10, 
        $11, $12, null, false, null,
         false)

    RETURNING id;
  `;
    return pool.query(text, [exercicio, observacao, datavencimento, sequenciall, tipodam, totalparcelas, ultimovencimento, valor, contribuinte_id, imovel_id, lancamentodiat_id, damorigem_id, datainscricao]);
}
async function updateDam(dam, id) {
    const datapagamento = dam.dt_pagamento ? convertDate(dam.dt_pagamento) : null;
    const datatransferencia = dam.data_certido ? convertDate(dam.data_certido) : null;
    const datavencimento = dam.vencimento ? convertDate(dam.vencimento) : null;
    const exercicio = dam.exerccio;
    const numeroparcela = dam.parcela;
    const statusdam = datapagamento ? 1 : (datatransferencia ? 3 : 2);
    const totalparcelas = dam.qtd_parcelas ? dam.qtd_parcelas : 0;
    const valor = dam.valor_original_do_iptu ? toUS(dam.valor_original_do_iptu) : 0;
    const valorpago = dam.valor_pago ? toUS(dam.valor_pago) : 0;
    const contribuinte_id = dam.contribuinte_id;
    const imovel_id = dam.imovel_id;
    const dataemissao = datapagamento ? datapagamento : datavencimento;
    const observacao = "CONCILIACAO UPDATE: " + dam.situao + " - " + new Date().toLocaleDateString() + " - " + dam.sequencial;
    let text = `
    update lanc_dam set
        datapagamento = $2, datatransferencia  = $3, datavencimento  = $4, exercicio = $5, 
        numeroparcela = $6, statusdam = $7, totalparcelas = $8, valor = $9, valorpagamento = $10, 
        valorpago = $11, valortotal = $12, contribuinte_id = $13, imovel_id = $14, dataemissao = $15, 
        observacao = $16, aliquota = 0, correcao = 0, juros = 0, multa = 0, taxaexpediente = 0, valordesconto = 0, valortotalbase = 0, percentualdesconto = 0 
        where id = $1  
  `;
    text += ' and (datapagamento is null or datapagamento <= $2)';

    return pool.query(text, [id,
        datapagamento, datatransferencia, datavencimento, exercicio,
        numeroparcela, statusdam, totalparcelas, valor, valorpago, valorpago, valor, contribuinte_id, imovel_id, dataemissao,
        observacao
    ])
}


async function updateObsDam(obs, id, dam) {
    const observacao = "CONCILIACAO UPDATE: " + obs + " " + dam.situao + " - " + new Date().toLocaleDateString() + " - " + dam.sequencial;
    const text = `
    update lanc_dam set
        observacao = $2
        where id = $1
    `;
    return pool.query(text, [id, observacao]);
}

async function getDividas(exercicio, contribuinte, imovel) {
    const text = `
    select * from divida_ativa_dam where exercicio = $1 and contribuinte_id = $2 and imovel_id = $3
  `;
    return pool.query(text, [exercicio, contribuinte, imovel]);
}

async function insertDiat(diat) {
    const {
        dataemissao,
        exercicio,
        numeroparcelas,
        primeirovencimento,
        ultimovencimento,
        valorpago,
        valortotal,
        contribuinte_id,
        statusnegociacao,
        dataatualizacao,
        obs
    } = diat;

    const text = `
        INSERT INTO public.lanc_diat (
            dataemissao, 
            exercicio, 
            numeroparcelas, 
            primeirovencimento,
            ultimovencimento,
            valorpago,
            valortotal,
            contribuinte_id,
            statusnegociacao,
            dataatualizacao,
            obs,
            valorusadosaldoanterior
        ) values (
            $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, 0
            )
        RETURNING id;
    `;
    return pool.query(text, [
        dataemissao,
        exercicio,
        numeroparcelas,
        primeirovencimento,
        ultimovencimento,
        valorpago,
        valortotal,
        contribuinte_id,
        statusnegociacao,
        dataatualizacao,
        obs
    ]);
}

async function insertHistoricoDiat(dividaId, diatId) {
    const text = `
        INSERT INTO public.divida_ativa_historico_negociacao (
            divida_id, lancamentodiat_id )
            VALUES (
                $1, $2
            )

            RETURNING id;
        `;
    return pool.query(text, [dividaId, diatId]);
}

module.exports = {
    init,
    getContribuintes,
    getDebitos,
    getDebitosParcelados,
    getCadastroImobiliario,
    getDams,
    getMaxSequencial,
    insertDam,
    updateDam,
    updateObsDam,
    getDividas,
    insertDivida,
    getMaxSequencialDivida,
    insertDiat,
    insertDiatDam,
    insertHistoricoDiat,
    ifExistDam,
    getParcelamentos
};